﻿using UnityEngine;
using System.Collections;

public class                                                                    LookTowardsMouse : MonoBehaviour
{
    public float movementSpeed = 5.0f;
    public float clockwise = 1000.0f;
    public float counterClockwise = -5.0f;

    // Update is called once per frame
    void Update()
    {

        //Get the Screen positions of the object
        Vector2 positionOnScreen = Camera.main.WorldToViewportPoint(transform.position);

        //Get the Screen position of the mouse
        Vector2 mouseOnScreen = (Vector2)Camera.main.ScreenToViewportPoint(Input.mousePosition);

        //Get the angle between the points
        float angle = AngleBetweenTwoPoints(positionOnScreen, mouseOnScreen);

        //Ta Daaa
        transform.rotation = Quaternion.Euler(new Vector3(0f, 0f, angle));

        position pos = transform.position;

        //you can transform position 'up, down, left, right, forward, backward'
        //pos = transform.position;
        if (Input.GetKey(KeyCode.A)) {
           //pos.x += cos(angle);
           //pos.y += cos(angle);
           //pos.z += cos(angle);

            Debug.Log("Pressing A");
        }
        if (Input.GetKey(KeyCode.W))
        {
            Debug.Log("Pressing W");

            //transform.position = new Vector3(0, 0, 0);
        }
        if (Input.GetKey(KeyCode.S))
        {
            Debug.Log("Pressing S");
           // transform.position = new Vector3(0, 0, 0);
        }
        if (Input.GetKey(KeyCode.D))
        {
            Debug.Log("Pressing D");
           // transform.position = new Vector3(0, 0, 0);
        }
        //transform.position = Vector3.MoveTowards(transform.position, pos, movementSpeed * Time.deltaTime);
    }

    float AngleBetweenTwoPoints(Vector3 a, Vector3 b)
    {
        return Mathf.Atan2(a.y - b.y, a.x - b.x) * Mathf.Rad2Deg + 90;
    }

}
// float step = speed * Time.deltaTime;
// MOVE TOWARDS! transform.position = Vector3.MoveTowards(transform.position, target.position, step);